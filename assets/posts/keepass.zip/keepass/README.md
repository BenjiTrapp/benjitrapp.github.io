# KeePass DLL Proxying Demo

## Content
Within this Zip you can find the following things:

```bash
.
├── dll_to_def.py         # Creates the .def file based on a given dll
├── payload.c             # Malicious Code functions 
├── README.md             # You're reading it right now :D
├── KeePassXC-2.6.6-Win32-portable
├── userenv-dll           
│   ├── userenv.def       # The .def file based on userenv_orig.dll
│   ├── userenv.dll       # Compiled version with the Malicious Code
│   └── userenv_orig.dll  # Original userenv.dll from Windows
└── version-dll
    ├── version.def       # The .def file based on version_orig.dll
    ├── version.dll       # Compiled version with the Malicious Code
    └── version_orig.dll  # Original version.dll from Windows
```

# How to run this Demo

1. copy either the `userenv.dll` together with `userenv_orig.dll` or the equivalent for the `version.dll` into `KeePassXC-2.6.6-Win32-portable`
2. Run the KeePassXC application and check if the calculator is getting started as well