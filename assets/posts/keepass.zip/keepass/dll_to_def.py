import pefile

file_name = 'userenv64'
dll = pefile.PE(f'{file_name}.dll')

exports = filter(lambda export: export.name is not None, dll.DIRECTORY_ENTRY_EXPORT.symbols)
formatted_exports = map(lambda export: '{0}={1}.{2} @{3}\n'.format(export.name.decode(), file_name, export.name.decode(), export.ordinal), exports)

with open(f'{file_name}.def', 'w') as file:
    file.write("EXPORTS\n")
    for formatted_export in formatted_exports:
        print(formatted_export, end='')
        file.write(f"{formatted_export}")